# How to run these tests

Run one:

  `rspec spec/the/test.rb`

Run them all:

  `rspec spec/**/*.rb`

Debug one test:

  `LOGSTASH_DEBUG=y rspec spec/the/test.rb`

